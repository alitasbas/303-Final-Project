Distribution of Data 3 is:

data set 34: Gamma(alfa=5, beta=1)
